﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AuthorityOnSpawnedObjectsIsCorrect_BridgeScript : MonoBehaviour
{
    public const string bridgeGameObjectName = "AuthorityOnSpawnedObjectsIsCorrect_BridgeScriptGO";

    public GameObject playerWithAuthPrefab;
    public GameObject noAuthObjPrefab;
    public GameObject authObjPrefab;
}
